# -*- coding: utf-8 -*-
"""
Created on Thu Apr 22 17:56:41 2021

@author: Dom Horard
CS521 O2
04/22/2021

The human body has many organs. These organs have some properties in common and
others that are specialized.
 Create an Organ class as a base class for specific organs
    o Attributes for the organ class are:
         organ_name
         organ_weight_grams
         is_vital_organ
         organ_system
         is_transplantable
         organ_gender
o Required reserved methods for organ class:
     Constructor
     Repr method that returns the attributes of organ instance
 Create a Heart class as a child of the organ class
    o The heart is a vital organ in the Muscular system
    o Attributes for heart, defined in the constructor, are:
         heart_length_cm
         heart_weight_grams (use the parent class)
         heart_thickness_cm
         heart_breadth_cm
    o Required reserved methods for heart class:
         Constructor
         Repr method that returns the attributes of heart instance
    o Required general methods for heart class:
         heart_status – returns ‘Pumping blood’
         heart_weight_oz – returns the heart weight in ounces
             1 gram = 0.035 ounces
 Create a Brain class as a child of the organ class
    o The brain is a vital organ in the Nervous system
    o Attributes for brain, defined in the constructor, are:
         brain_volume (in centimeters)
         brain_weight_gram (use the parent class)
    o Required reserved methods for brain class:
         Constructor
         Repr method that returns the attributes of brain instance
    o Required general methods for brain class:
         brain_status – returns ‘Thinking’
         brain_weight_oz – returns the brain weight in ounces
             1 gram = 0.035 oz
"""

class Organ():
    '''Parent class for Organs'''
    
    #Defining contructor attributes for the Organ class
    def __init__(self, organ_name = '', organ_weight_grams = 0, \
                 is_vital_organ = '', organ_system = '',\
                     is_transplantable = '', organ_gender = ''):
        
        #self is referring to the relevant, calling, object
        #assigning input argument to instance variable as a private attribute
        self.organ_name = organ_name
        
        self.organ_weight_grams = organ_weight_grams
        
        self.is_vital_organ = is_vital_organ
        
        self.organ_system = organ_system
        
        self.is_transplantable = is_transplantable
        
        self.organ_gender = organ_gender
        
    #Defining the representation method for the class
    def __repr__(self):
        
        return f'The {self.organ_name} weighs {self.organ_weight_grams}g.' + \
            f' Is it a vital organ? {self.is_vital_organ}.' + \
                f' Is it transplantable? {self.is_transplantable}.' + \
                    f' And the organ \"gender\" is {self.organ_gender}'
                    
    
#Defining Child class that has the parent class as a parameter
class Heart(Organ):
    '''Child class to the Organ class'''
    
    #Inheretence of the parent's __init__ function with a call
    #Defining contructor attributes for the Organ class and adding Heart class
    #attributes
    def __init__(self, organ_name = 'Heart', organ_weight_grams = 0, \
                 is_vital_organ = True, organ_system = '',\
                     is_transplantable = True, organ_gender = 'Male',\
                         heart_length_cm = 0, \
                             heart_thickness_cm = 0, \
                                 heart_breadth_cm = 0):
        
        #Inherit methods and properties from the parent class 
        Organ.__init__(self, organ_name, organ_weight_grams, \
                 is_vital_organ, organ_system,\
                     is_transplantable, organ_gender)
        
        #Attributes specific to the heart
        self.heart_organ_name = organ_name
        
        self.heart_weight_grams = organ_weight_grams
        
        self.heart_length_cm = heart_length_cm
        
        self.heart_thickness_cm = heart_thickness_cm
        
        self.heart_breadth_cm = heart_breadth_cm
                            
    
    #General methods for the Heart class
    def heart_status(self):
        '''Here, here! It is the beating of his hideous heart!'''
        '''Return a status of the hideous heart'''
        
        return 'Pumping blood'
    
    #Converting the weight of the heart from grams to ounces
    def heart_weight_oz(self):
        '''I smiled,—for what had I to fear'''
        '''Convert heart weight from grams to ounces'''
        
        self.heart_weight_oz = round(self.organ_weight_grams / 28.35, 2)
        
        #Return the weight of the heart in ounces
        return f'The {self.organ_name} weighs {self.heart_weight_oz} ounces'
    
    #Defining a representation method for the class
    def __repr__(self):
        
        return f'This {self.organ_name} weighs {self.heart_weight_grams}' + \
            f'oz, and is {self.heart_length_cm}cm in length. It is ' + \
                f'{self.heart_thickness_cm}cm thick, and ' + \
                    f'{self.heart_breadth_cm}cm in breadth. It is part of' + \
                        f' the {self.organ_system}. Is it a vital organ?' + \
                            f' {self.is_vital_organ}' + \
                                ' Is it transplantable?' + \
                                f' {self.is_transplantable}.' + \
                    f' And the organ \"gender\" is {self.organ_gender}'
        

#Defiing a child class for the Organ parent class
class Brain(Organ):
    
    #Inheretence of the parent's __init__ function with a call
    #Defining contructor attributes for the Organ class and adding Heart class
    #attributes
    def __init__(self, organ_name = 'Brain', organ_weight_grams = 0, \
                 is_vital_organ = True, organ_system = 'Nervous',\
                     is_transplantable = False, organ_gender = 'Female',\
                         brain_volume = 0):
        
        #Inherit methods and properties from the parent class 
        Organ.__init__(self, organ_name, organ_weight_grams, \
                 is_vital_organ, organ_system,\
                     is_transplantable, organ_gender)
        
        #Attributes specific to the heart
        self.brain_weight_grams = organ_weight_grams
        
        self.brain_volume = brain_volume
        
        
    #General methods for the Heart class
    def brain_status(self):
        '''I think, therefore I am'''
        '''Return a status of the busy mind'''
        
        return 'Thinking'
    
    #Converting the weight of the heart from grams to ounces
    def brain_weight_oz(self):
        '''I smiled,—for what had I to fear'''
        '''Convert heart weight from grams to ounces'''
        
        self.brain_weight_oz = round(self.organ_weight_grams / 28.35, 2)
        
        #Return the weight of the heart in ounces
        return f'The {self.organ_name} weighs {self.brain_weight_oz} ounces'

    #Defining a representation method for the class
    def __repr__(self):
        
        return f'This {self.organ_name} weighs {self.brain_weight_grams}' + \
            f'g, and is {self.brain_volume}cm in volume. Is it vital? ' + \
                f'{self.is_vital_organ}. System is {self.organ_system}'+ \
                    f' Is it transplantable? {self.is_transplantable}.' + \
                        f' And has a gender of {self.organ_gender}'
        
#If the name of the terminal that the program is run in is 'main'        
if __name__ == '__main__':

    lungs1 = Organ(organ_name = 'Lung',\
                    organ_weight_grams = 23,\
                        is_vital_organ = 'No',\
                            organ_system = 'Respritory',\
                                is_transplantable = True,\
                                    organ_gender = 'Male')
    print(lungs1)
    
    heart8 = Heart(organ_weight_grams = 12,heart_length_cm = 2,\
                                           heart_thickness_cm = 3,\
                                               heart_breadth_cm= 5)
    print(heart8)
    print(heart8.heart_status())
    print(heart8.heart_weight_oz())
    
    brain1 = Brain(organ_weight_grams = 12, brain_volume = 3)
    print(brain1)
    print(brain1.brain_status())
    print(brain1.brain_weight_oz())
    
    #Running dir to show that there are matching attributes between the 
    #child and parent class
    print(dir(brain1))
    print(dir(heart8))
    print(dir(lungs1))
    
    #Using assert to test if an error is thrown when giving the wrong value for
    #an attribute
    assert brain1 == Brain(organ_weight_grams = '1270', brain_volume = 1370.0)\
        , 'Not a number'
    
    assert heart8 == Heart(organ_weight_grams = "6",\
                    organ_gender = 'Female',\
                        heart_length_cm = 9,\
                            heart_thickness_cm = 5,\
                                heart_breadth_cm = 31), 'Not a number'

    