# -*- coding: utf-8 -*-
"""
Created on Tue Apr 20 10:36:09 2021

@author: Dom Horard
CS521 O2 
04/20/2021

Write a python program using the following requirements:
Create a class called Sentence which
 has a constructor that takes a sentence string as input.
    o The default value for the constructor should be an empty string
    o The sentence must be a private attribute in the class
 contains the following class methods:
    o get_all_words — Returns all the words in the sentence as a list
    o get_word — Returns only the word at a particular index in the sentence
 Arguments: index
    o set_word — Changes the word at a given index in sentence to a new word
 Arguments: index, new_word
 Does not return anything
    o a str method — Returns the sentence as a string using the built‐in method
"""

class Sentence():
    '''Sentece class with 4 methods'''
    
    #Constructor that calls on the object itself, and there is a default
    #value for sentence of an empty string
    def __init__(self, sentence=''):
        '''initializer for the Class Object instance'''
        
        
        #defing an empty list to append words from the sentence into in a list
        #for the other object methods
        self.word_list = [word for word in sentence.split()]
        
        #self is referring to the relevant, calling, object
        #assigning input argument to instance variable as a private attribute
        self.__sentence = sentence
        
    
    #Object method to get all the words in the sentence
    def get_all_words(self):
        '''Get all the words from the sentence list'''
        import string
        
        #Using the string module, stripping the words in the list of any
        #punctuation marks
        self.pure_word_list = [word.strip(string.punctuation) for word in \
                               self.word_list]
        
        #Returning the list of words to the user
        return f'List of words from the sentence: {self.pure_word_list}'
    
    
    def get_word(self, index):
        '''Get a specific word from the index in the pure word list'''
        
        #Defining variable that is the value of a word in the pure word list
        #that the user entered an idex value for
        self.pure_word_list[index]
        
        #Return the word at the specified index
        return f'{self.pure_word_list[index]}'
        
    def set_word(self, index, new_word):
        '''Change the word at a specific index in the list to something
        else
        '''
        #Removing the word in that specific index using .pop function
        self.pure_word_list.pop(index)
        
        #Using insert to change insert a word at the specified index with a new
        #word
        self.pure_word_list.insert(index, new_word)
        
        #Join the words in the list to a single string
        self.new_sen = ' '.join(self.pure_word_list)
        
    def __str__(self):
        '''Used to print our sentence object'''
        # return 'The original sentence was: ', self.__sentence
        # return 'The new sentence is: ', ' '.join(self.pure_word_list)
        return f'Original: {self.__sentence} \nNew: {self.new_sen}'
            
#If the name of the terminal that the program is run in is 'main'            
if __name__ == '__main__':
    
    sen = Sentence(sentence = 'This is a test of the emergency method system')
    print(sen.get_all_words())
    print(sen.get_word(3))
    sen.set_word(2, 'another')
    print(sen)
    
    #Unit testing with assert statment
    assert sen == Sentence(sentence = True),'Not a string'