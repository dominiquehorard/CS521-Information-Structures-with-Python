# -*- coding: utf-8 -*-
"""
Created on Fri Apr  9 20:01:04 2021

@author: Dom Horard
CS 521 O2
04/09/2021

Create a program that:
 prompts a user for a number
 validates that a number was entered
 re‐prompts on error
 converts the number to words using a dictionary
 prints out the converted numbers as words
The program must only have one input command and work for any size positive or 
negative number.
Decimal point should be converted to ‘point’.
If the user enters commas, tell them to try again without the commas.
"""

#Creating a list of numbers and words to zip into a dictionary later
nums_list = ['-','0','1','2','3','4','5','6','7','8','9','.']
words_list = ['Negative','Zero','One','Two','Three','Four','Five','Six'\
              ,'Seven','Eight','Nine','Point']

#Zip the lists
num_to_word_zip = zip(nums_list,words_list)
#Convert zip into dictionary
num_to_word_dict = dict(num_to_word_zip)

#While loop that re-prompts the user for a valid string
while True:
    
    #Prompt user for a number
    user_input = input('Please enter a number: ')
    #Create a list with each element being the number entered in as a string
    user_input_list = [char for char in user_input]
    
    #If string has a comma in it print message and reprompt
    if ',' in user_input:
        print('Please enter a number without commas.')
    
    #If the input can't be converted to a digit then prompt with error
    elif user_input.isdigit() == False and (user_input.isupper() or \
                                          user_input.islower()):
        print('Please enter numbers or \'.\' only')
    #Else, make a new list that gets the value for the number key in the user
    #list
    else:
        converted_num = [num_to_word_dict.get(num) for num in user_input_list]
        #Print the elements in that new list
        print('As text:', *converted_num)
        #End the loop
        break
