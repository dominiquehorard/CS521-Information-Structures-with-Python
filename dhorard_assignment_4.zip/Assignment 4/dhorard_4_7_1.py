# -*- coding: utf-8 -*-
"""
Created on Tue Apr  6 20:34:33 2021

@author: Dom Horard
CS 521 O2
04/06/2021

Given a constant list of integers in the range 1 to 10 inclusive, use list 
comprehension (no explicit loops) to:
 find the sum of the even integers in list L.
 find the sum of the odd integers in list L.
"""
#Define contants with desired range values
S =  1
E = 10
#Define contant with the range as a list
X = list(range(S,E + 1))

#List comprehension to check if the numbers in the contant are even or odd
#and add them to a new list
even_numbers_list = [num for num in X if num % 2 == 0]
odd_numbers_list = [num for num in X if num % 2 != 0]

#Print the lists, and the sum of the values in the list made via list 
#comprehension
print('Evaluating the numbers in: {}'.format(X))
print('Even: {}'.format(sum(even_numbers_list)))
print('Odd: {}'.format(sum(odd_numbers_list)))
