# -*- coding: utf-8 -*-
"""
Created on Thu Apr  8 18:01:38 2021

@author: Dom Horard
CS 521 O2
04/08/2021

Start with 2 constant lists. One with first names and another of last names.
First validate that both lists are the same size and if not, exit with an error
message. Use zip to create a dictionary with the keys as the last names and the
values as the first names. Print the generated dictionary with an appropriate 
description.
"""
#Create two lists
F = ['Ash', 'Jotaro', 'Light']
L = ['Ketchum', 'Kujo', 'Yagami']

#Check to see if the two lists are equal and print error if not
try:
    F == L
except:
    print('These lists are not equal')
else:
    #Print the lists
    print('First Names:', F)
    print('Last Names:', L)
    #Zip the lists together, making tuples of the elements that are paired
    full_names_zipped = zip(F,L)
    #Convert zip into a dictionary
    full_names_dict = dict(full_names_zipped)
    #Print the dictionary
    print('Full Names Dictionary:', full_names_dict)