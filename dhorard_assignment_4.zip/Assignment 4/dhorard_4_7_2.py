# -*- coding: utf-8 -*-
"""
Created on Tue Apr  6 22:53:49 2021

@author: Dom Horard
CS 521 O2
04/06/2021
Given a constant list of integers, write Python code to generate a new list
with same number of elements as the original list such that each integer in the
new list is the sum of its nearest neighbors and itself from the original list. 
Print both lists with descriptions. Your code should be able to work with an 
integer list of any size.
"""
#Starting point for the range set to constant
S = 10
#Endpoint for the range set to constant
E = 60
#Defining the list as a range from 10 to 60, but only including numbers that
#are incremented by 10
X = list(range(S, E, 10))
#Empty list to append added values to
Y = []
#Append the cumulative value of elements in postion 0 and 1 of the list to the 
#empty list Y
Y.append(X[0] + X[1])
#Assigning value of variable i to 1 because we have already added values in 
#position 0 and 1 to the new list Y
i = 1
#While i is length of X - 1 (Will add those values together separately)
while i < len(X) - 1:   
#Append to list Y the value of i in X with the value of the element that comes
#before and after it
    Y.append(X[i - 1] + X[i] + X[i + 1])  
#Add one to the value of i to iterate over again
    i += 1
#Because the loop does not account for the last two values in the list, we add
#those separately and append that to list Y
Y.append(X[i - 1] + X[i]) 
#Print the original list
print('Original List:', X)
#Print the new list
print('New List:',Y)
