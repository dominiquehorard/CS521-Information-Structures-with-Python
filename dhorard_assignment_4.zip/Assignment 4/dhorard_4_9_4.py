# -*- coding: utf-8 -*-
"""
Created on Thu Apr  8 20:21:39 2021

@author: Dom Horard
CS 521 O2
04/08/2021

Using my_dict = {'a':15, 'c':18, 'b':20}, write a program to:
a. print all the keys.
b. print all the values.
c. print all the keys and values pairs.
d. print all the keys and values pairs in ascending order of key.
e. print all the keys and values pairs in ascending order of value.
"""
#Initializing a dictionary
my_dict = {'a':15, 'c':18, 'b':20}

#Create a new list of the keys in the dictionary and print
keys = [key for key in my_dict]
print('Keys:', keys)

#Create a new list of the values in the dictionary and print
values = [val for key,val in my_dict.items()]
print('Values:', values)

#Create a new list of the keys value pairs and print as tuples
key_value = list(my_dict.items())
print('Key value pairs:',*key_value)

#Create a new list of the key value pairs in the dictionary, sorted, and print
#as tuples
keys_sorted = sorted(my_dict.items())
print('Key value pairs ordered by key:',*keys_sorted)

#Create a new list of the keys value pairs in the dictionary using the sorted()
#function and print
values_sorted = sorted(my_dict.items(), key=lambda item:item[1])
print('Key value pairs ordered by value:',*values_sorted)
