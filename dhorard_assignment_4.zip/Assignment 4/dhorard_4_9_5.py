# -*- coding: utf-8 -*-
"""
Created on Fri Apr  9 09:31:12 2021

@author: Dom Horard
CS 521 O2
04/09/2021

Create 3 functions with docstring:
1. letter_counts() takes a string as its argument and returns a dictionary 
of the letters as keys and frequency counts as values.

2. most_common_letter() takes a string as its argument and returns a string 
of the most common letter(s). In the case of a tie for the most common letter, 
return them all. This function should call letter_counts().

3. string_count_histogram() takes a string as its argument and returns a list 
of the unique letters, with each letter being the repeated number of times it 
appears in the string. This list will then be printed one element per line 
(as a histogram). This function should call letter_counts().

print statements should be in the __main__
"""
#Variable with the string being used for the function calls later
test_sen = 'THIS STRING IS SERIOUSLY WAY MORE THAN FIFTEEN CHARACTERS T'

#Print a general statement telling the user hat string we are analyzing
print('The string being analyzed is: \'{}\''.format(test_sen))

#Function to count the letters in a string using a dictionary
def letter_counts(str):
    """
    Parameters
    ----------
    x : string

    Returns
    -------
    dictionary of letters in the string with the frequency that they appear
    """
    #Empty dictionary to insert the letters into
    letter_count_dict = {}
    
    #Iterate over each character into the argument where all the spaces are 
    #replaced
    for letter in str.replace(' ', ''):
        
        #If the letter(key) is already in the dictionary, add 1 to it's count
        #(value)
        if letter in letter_count_dict:
            letter_count_dict[letter] += 1
            
        #If it's not in the dictionary, then add it to the dictionary with a
        #with a count of 1
        else:
            letter_count_dict[letter] = 1
            
    #Return the dictonary to use in the call for other functions and to print
    #later    
    return letter_count_dict

#Function that returns the most common letter 
def most_common_letter(str):
    """
    Parameters
    ----------
    x : string 

    Returns
    -------
    most common letter(s) from that string

    """
    
    #For loop that takes the string argument and calls the letter_count
    #function for the letters in the string and creates a dictonary
    for letter in str:
        letter_count_dict = dict(letter_counts(str))
        
    #Assigning the highest value for a key to a variable
    highest_letter_val = max(letter_count_dict.values())
    
    #Create a list for the key in the dictionary where the value is equal to 
    #the variable value
    most_common_list = [key for key,val in letter_count_dict.items()\
                        if val == highest_letter_val]
    
    #Printing the dictionary in this function to avoid the dictionary being 
    #printed multiple times from the letter_counts call
    print('1. Dictionary of letter counts: {}'.format(letter_count_dict))
    
    #Printing the most frequent letters in a readable format
    print('2. Most frequent letter(s) {} '.format(most_common_list) +
          'appears {} times.'.format(highest_letter_val))   

#Function that returns a histogram of the letters in the string times their
#value
def string_count_histogram(str):
    """
    Parameters
    ----------
    x : string.

    Returns
    -------
    list of unique letters  with each letter repeating the number of times it
    appears in the string

    """
    #Creating a dictionary from the returned dictionary in the called function
    #letter_counts
    letter_count_dict = letter_counts(str)

    #Create a list that is the key string repeated the amount of it's
    #corresponding value for the key value pair in the dictionary
    letters_x_values = [key*val for key,val in letter_count_dict.items()]
    
    #Printing histogram in a readable format
    print('3. Histogram:' ,  *letters_x_values , sep=('\n'))

#Used to run all the functions 
if __name__ == '__main__':
    letter_counts(test_sen)
    most_common_letter(test_sen)
    string_count_histogram(test_sen)