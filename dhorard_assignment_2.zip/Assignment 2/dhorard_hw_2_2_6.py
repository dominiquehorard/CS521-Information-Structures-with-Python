# -*- coding: utf-8 -*-
"""
Created on Thu Mar 25 11:20:27 2021

@author: Dom Horard
CS 521 O2
3/25/21
program that calculates and prints all the leap years from 1899 to
2021 using a for and while loop
"""
#Question 2_2_6
#create an empty list
year_list = []
#for loop looks for values between 1899(inclusive) and 2022(exclusive)
#and if the value's remainder is 0 when divided by for, not 0 when divided by 100, or is when divided by 400
#the value in that range is added to the end of the list as an int
#then those values are added to a new list as strings
#i then goes one up from the previous value
for counter in range(1899, 2022):
    if counter % 4 == 0 and (counter % 100 != 0 or counter % 400 == 0):
        year_list.append(counter)
        year_list_str = [str(int) for int in year_list]
#prints each year in the list with a comma seperating them
print(*year_list_str, sep=', ')
#insert blank line to seperate the two outputs
print(' ')

#While Loop
#define the two lists, this time defining the string list outside of the loop
year_list = []
year_list_str = []
#set i to 1899 because that's the start of the list range, and what we're going to iterate over
i = 1899
while i in range(1899, 2022):
#loop looks for values between 1899(inclusive) and 2022(exclusive)
#and if the value's remainder is 0 when divided by for, not 0 when divided by 100, or is when divided by 400
#the value in that range is added to the end of the list as an int
#then those values are added to a new list as strings
#i then goes one up from the previous value
    if i % 4 == 0 and (i % 100 != 0 or i % 400 == 0): 
        year_list.append(i)
        year_list_str = [str(int) for int in year_list]
    i += 1
#prints each year in the list with a comma seperating them
print(*year_list_str, sep=', ')