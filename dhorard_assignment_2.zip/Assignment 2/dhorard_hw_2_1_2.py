# -*- coding: utf-8 -*-
"""
Created on Thu Mar 25 09:40:44 2021

@author: Dom Horard
CS 521 O2
3/25/21
Prompt user for input and then print that input as a string, an integer, and a floating‐point
value.
"""

#Question 2.1.2
user_input = input('Write something: ')
#print statemetn converts the user's input to an int, float, or string
print(str(user_input), int(user_input), float(user_input))
#The datatyps that can be input without generating errors are integers and floating point numbers
