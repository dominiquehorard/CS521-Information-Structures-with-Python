# -*- coding: utf-8 -*-
"""
Created on Thu Mar 25 09:41:37 2021

@author: Dom Horard
CS 521 O2
3/25/21
Python program that asks the user to enter an integer (n) and computes the value of
n+n*n+n*n*n+n*n*n*n = ?. The program prints the formula, replacing the ‘n’
variables with the user input, and the ? with the calculation results.
"""
#Question 2.1.3
user_str = input('Enter an integer: ')
#Convert user input into a string to preform a calculation on later
user_int = int(user_str)
#'{:,}'.format() is used to seperate the digits in larger numbers
#No need for parentheses, multiplication will take precedence over addition in this operation
int_math = '{:,}'.format(user_int + user_int * user_int + user_int * user_int * user_int + user_int * user_int * user_int * user_int)
#Printing a string of curly braces, with the appropriate operators
#Then using the .format function to add in the user string, and the value stored in int_math
print('{} + {} * {} + {} * {} * {} + {} * {} * {} * {}'.format(user_str,user_str,user_str,user_str,user_str,user_str,user_str,user_str,user_str,user_str),\
      '= {}'.format(int_math))
