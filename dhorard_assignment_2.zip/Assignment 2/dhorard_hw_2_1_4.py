# -*- coding: utf-8 -*-
"""
Created on Thu Mar 25 10:14:31 2021

@author: Dom Horard
CS 521 O2
3/25/21
A three‐line program that (1) prompts for a number, (2)
converts the input to an integer and (3) prints the number 0 if the user input is even and the
number 1 if the user input is odd
"""
#Question 2_1_4
#Variable stores the user input as an int
user_int = int(input('Enter a number: '))
#prints 0 if there is no remainder
if user_int % 2 == 0: print(0) 
#1 if there is a remainder
else: print(1)
