# -*- coding: utf-8 -*-
"""
Created on Fri Mar 26 15:05:38 2021

@author: Dom Horard
CS 521 O2
3/26/21
Rewrite this following ‘for loop’ as a ‘while loop’ and create a working program:
(Note that X is upper case because it is defined as a constant)
X = 10
for i in range(1, X + 1):
    if X % i == 0:
            print(i)
"""
#set i to 1
i = 1
#while i is less than or equal to 10, the value of i will print if the remainder is equal to 0
#i then iterates up one
while i <= 10:
	if 10 % 1 == 0:
		print(i)
	i += 1