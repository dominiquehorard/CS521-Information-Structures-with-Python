# -*- coding: utf-8 -*-
"""
Created on Thu Mar 25 21:04:25 2021

@author: Dom Horard
"""



#for counter in range(1899, 2022):
#     if counter % 4 == 0:
#         year_list.append(counter)
#         year_list_str = [str(int) for int in year_list]
# print(*year_list_str, sep=',')
            
# year_list = []
# year_list_str = [str(int) for int in year_list]
# i = 0
# while i < len(year_list):
#     for counter in range(1899, 2022):
#         year_list.append(counter)
#         if year_list[i] % 4 == 0: 
#             i += 1
#         print(*year_list_str, sep=',')

i=0
while i < 31:
    year_list = []
    year_list_str = []
    for counter in range(1899, 2022):
            if counter % 4 == 0: 
                year_list.append(counter)
                year_list_str = [str(int) for int in year_list]
                i += 1
    print(*year_list_str, sep=',')