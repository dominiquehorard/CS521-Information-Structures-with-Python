# -*- coding: utf-8 -*-
"""
Created on Thu Mar 25 10:42:58 2021

@author: Dom Horard
CS 521 O2
3/25/21
Program prompts user for weight and height in one input, performs BMI calculation, and prints BMI calculation with an appropriate description
"""
#Question 2_1_5
#defined two variables seperated by a comma
#.split() function is have we store the two values in the distinct variables
user_weight, user_height = input('Enter Weight in kilograms and Height in meters (separated by a space):').split()
#convert values from string to floats
weight_int = float(user_weight)
height_int = float(user_height)
#BMI calculation formula
BMI = weight_int / height_int**2
#Using .format() function to place the variable values in the curly braces of the string
print('Body Mass Index (BMI) for Weight {}'.format(weight_int), ' and Height {}'.format(height_int), ': {}'.format(BMI))