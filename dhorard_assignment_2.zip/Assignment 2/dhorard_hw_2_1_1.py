# -*- coding: utf-8 -*-
"""
Spyder Editor

@author: Dom Horard
CS 521 O2
3/25/21
Python program prompts the user to enter a number. In one calculation, take
that number, add 2, multiply by 3, subtract 6, and divide by 3.
"""
# Question 2.1.1
#saving the user input to a variable as a string
number_str = input('Enter a number: ')
#changes the string type to an int
number_int = int(number_str)
#store the value of the operation as an int to compare against the original user input later
#parenthetical needed to ensure the math is done in the proper order
calculation_int =  int((( number_int + 2 ) * 3 - 6 ) / 3) #parenthesis to ensure that the calculations are done in the right order
#simple if statement to check if the value after the operations are performed is equal to the user's original input
if  number_int == calculation_int:
    print('We did some math, and our calculations returned the same number!')
