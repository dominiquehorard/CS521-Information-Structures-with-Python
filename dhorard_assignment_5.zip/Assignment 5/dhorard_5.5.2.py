# -*- coding: utf-8 -*-
"""
Created on Thu Apr 15 11:34:23 2021

@author: Dom Horard
CS521 O2
04/15/2021

• takes as input from the user a date and time (24-hour clock) as 
"MM/DD/YYYY HH:mm:SS"
    o Assume that everything must be provided with leading 
    zeros
• calls the function is_ validate_datetime () that:
    o takes a string argument
    o validates that the string has all the elements to be a valid date 
    and time
    o returns 2 values:
        ▪ Boolean true if valid or false if invalid date/time
        ▪ None if valid or an error message string if invalid
• If the input string is returned from the function as invalid, 
   print the returned error message.
• If the input string is returned from the function as valid, 
    use input string to print following:
        o MM/DD/YYYY
        o HR:MIN:SEC
        o MM/YYYY
        o Whether the time is “AM” or “PM”
"""

#Import sys module to exit if the date entered is not in the proper format
import sys

#Prompt the user to enter a date and time in try block for errors
try:
    
    user_date, user_time = input('Enter a date time ' + \
            '(seperated by a space as MM/DD/YYYY HH:MM:SS): ')\
            .split()
            
#Catch errors in the user's input,  print error, and exit
except ValueError:
    
    print('Please enter a full date and time as sepcified...Goodbye!')
    sys.exit()
        
#Create lists that split the input based on the / and : characters    
date_list = user_date.split('/')
time_list = user_time.split(':')

#Check if the date/time can't be seperated because of invalid character input
if len(date_list) == 1 or len(time_list) == 1:
    print('Please enter a date seperated by \'/\',' +
          ' and time seperated by \':\'...Goodbye')
    sys.exit()    
    
def is_validate_datetime(date,time):
    '''
    Parameters
    ----------
    str : user entered string

    Returns
    -------
    Boolean tuple of true or false values if invalid date/time
    None if valid or an error message string if invalid

    '''
    
    #Keep track of the length of the month string the user entered
    month_length,day_length,year_length = 0,0,0
        
    #For loop to increment the value of the month, day, and year length counter
    for digit in date_list[0]:
            month_length += 1
    for digit in date_list[1]:
            day_length += 1
    for digit in date_list[2]:
            year_length += 1
        
    #Variables to keep track of the length of the HH,MM,SS string for time 
    #input
    hour_length, min_length, sec_length = 0, 0, 0
        
        #For loops to increment the value of the time variable counters, 
        #all values between the seperated by : will be 2 in length
    for digit in time_list[0]:
           hour_length += 1
    for digit in time_list[1]:
           min_length += 1
    for digit in time_list[2]:
           sec_length += 1
            
    #List to check if the user entered a month that is in this list and
    #has an invalid day date entered        
    mon_list_1 = ['01','03','05','07','08','10','12']
    mon_list_2 = ['04','06','09','11']
    leap_month = ['02']
        
    #Defining leap year as false by default, a check will be made later to turn 
    #it to true if it is a valid leap year date for february
    leap_year = False
        
    #Check if year is in leap year list later
    leap_year_list = []
    
    #for loop looks for values between 1000(inclusive) and 10000(exclusive)
    #and if the value's remainder is 0 when divided by for, not 0 when divided
    #by 100, or is when divided by 400 the value in that range is added to the 
    #end of the list as an int
    for year in range(1000, 10000):
            if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0):
                leap_year_list.append(year)
        
    #Used later to check if the date was valid, default to true unless an 
    #entered date is invalid
    is_valid_date = True
        
    #Same as is_valid_date, but for time
    is_valid_time = True
    
    #Variable for valid date/time that will be used later to return true if
    #both values are valid
    valid_date_time = True
        
    '''
    ==========================================================================
            ****CHECK FOR VALID DATE****
    ==========================================================================
    '''
                
    #Check if the length of the first element in the date list, the month, 
    #is not equal 2, if it is grearter than 13, or equal to 0
    if month_length != 2 or int(date_list[0]) > 13 \
        or int(date_list[0]) == 0:
                    
            is_valid_date = False
            print('Invalid: Months must be entered with leading zeros' +\
                  'from 01 to 12')
    #Check if the day length is 2 for valid dates        
    elif day_length != 2:
                   
            is_valid_date = False
            print('Invalid: Enter a valid day date with a leading 0')
            
    #Check if the day length is 2 for valid dates        
    elif year_length != 4:
                   
            is_valid_date = False
            print('Invalid: Enter a valid year date from 1000 to 9999')
                    
    #Else if check that the month is in the 31-day-month list, the day element
    #is not in the range of 1 to 31
    elif date_list[0] in mon_list_1 and int(date_list[1]) not\
        in range(1,32):
                        
            is_valid_date = False
            print('Invalid: This month needs between 1 and 31 days')
        
                        
    #Else if check that the month is in the 30-day-month list, the day element
    #is not in the range of 1 to 30
    elif date_list[0] in mon_list_2 and int(date_list[1]) not\
        in range(1,31):
                        
            is_valid_date = False
            print('Invalid: This month needs between 1 and 30 days')    
        
    #Check for valid year starting at the Julian Calendar
    elif int(date_list[2]) < 1000:
            
            is_valid_date = False
            print('Invalid: Year is not valid, please enter years' + \
                  'between 1000 and 9999 inclusive')
                    
    #Check if the date is a valid leap year date for February
    elif date_list[0] in leap_month and\
        int(date_list[1]) in range(1,30) and \
        int(date_list[2]) in leap_year_list:
            
            #If it is, turn leap_year true
            leap_year = True
                     
    #Check if it's a valid date for the month of February, using the 
    #leap_year = false to make sure there is no leap year exception
    elif date_list[0] in leap_month and int(date_list[1]) not in \
                range(1,29) and leap_year == False:
                    
                is_valid_date = False
                print('Invalid: This is not a valid date for February')
                
    elif is_valid_date == False and leap_year == False:
                print('Invalid: This is not a valid Leap ')
            
    """
    Valid February date otherwise
    """
    
    '''
    At this point the date is valid
    '''                         
    '''
    ==========================================================================
            ****CHECK FOR VALID TIME****
    ==========================================================================
    '''
    #if/elif loops to check that all inputs for HH,MM,SS are 2 in length
    if hour_length != 2:
                    
             is_valid_time = False
             print('Invalid: Hour length must have leading 0 and be'\
                   + ' two digits long')
                 
    elif min_length != 2:
                    
             is_valid_time = False
             print('Invalid: Minutes length must have leading 0 and be'\
                   + ' two digits long and valid')
        
    elif sec_length != 2:
                    
             is_valid_time = False
             print('Invalid: Seconds length must have leading 0 and be'\
                   + ' two digits long and valid')
                 
    #elif loops test that the values for the HH:MM:SS are appropriate for an 
    #actual time            
    elif int(time_list[0]) > 24 or int(time_list[0]) == 0:
             is_valid_time = False
             print('Invalid: Hour length must have leading 0 and be between'\
                   + ' 01 and 24 inclusive')
    elif int(time_list[1]) >= 60:
            is_valid_time = False
            print('Invalid: Minute length must have leading 0 and between'\
                   + ' 01 and 60 exclusive')
    elif int(time_list[2]) >= 60:
            is_valid_time = False
            print('Invalid: Second length must have leading 0 and between'\
                   + ' 01 and 60 exclusive')
    '''
    At this point the time is valid
    '''
            
    '''
    ==========================================================================
            ****FINAL CHECK FOR VALID DATE & TIME****
    ==========================================================================
    '''
    #If either of the validity variables come back false... the 
    if is_valid_date == False and is_valid_time == True or \
       is_valid_date == True and is_valid_time == False:
           
           valid_date_time = False
           # print(valid_date_time, 'The date and time entered is invalid')
           
    #Returning a tuple of True or False values    
    return valid_date_time,is_valid_date,is_valid_time
    
#If the name of the terminal that the program is run in is 'main'
if __name__ == '__main__':
    
    #Assign value returned by the function to a variable
    valid_date = is_validate_datetime(user_date,user_time)     
    
    #If all the values in the tuple are true... print the date and time in 
    #various formats
    if valid_date == (True,True,True):
        print('MM/DD/YYYY is' , '/'.join(date_list))
        print('HH:MM:SS is', ':'.join(time_list))
        print('MM/YYYY is', '/'.join(date_list[::2]))
        if int(time_list[0]) > 11 and int(time_list[0]) < 24:
            print('The time is PM')
        else:
            print('The time is AM')
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        