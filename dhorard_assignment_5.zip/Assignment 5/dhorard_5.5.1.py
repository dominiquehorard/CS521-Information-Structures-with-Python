# -*- coding: utf-8 -*-
"""
Created on Tue Apr 13 08:44:45 2021

@author: Dom Horard
CS 521 O2
04/13/2021

Write a python program that does the following:
• takes as input from the user an English sentence
• calls the function vc_counter() that:
o takes a string argument
o counts the number of vowels and consonants in the string
o returns a dictionary of the counts, using the keys total_vowels 
and total_consonants
• Uses the return from vc_counter() to print the total vowels and 
consonants with appropriate descriptions.
"""
#Ask user for an input
user_input = input('Enter an English sentence: ')

def vc_counter(str):
    """
    Parameters
    ----------
    str : user entered string

    Returns
    -------
    total values for consonants and vowels in the user's string
    """
    #Import string module to exclude characters in the user's string
    import string
    
    #Remove the spaces in the string
    user_input.replace(' ', '')
    
    #create a list for the characters in the user string that aren't 
    #punctuation
    char_list = [char for char in user_input.lower() if char not in \
             string.punctuation and char.isdigit() == False]
    
    #Declaring list to check if these string contains characters in it
    v_list = ['a','e','i','o','u']
    
    #Dictionary comprehension to create the vowels dict for characters in the
    #string that are in the vowels list
    v_dict = {char:0 for char in char_list if char in v_list}
    
    #Dictionary comprehension to create the consonants dict for characters
    #in the string that are not in the vowels list and not punctuation
    c_dict = {char:0 for char in char_list if char not in v_list}
    
    #Create if statement that checks if the element in that converted list is 
    #in the vowels list.
    for char in char_list:
        
        #If it is, then we increment the value associated to the key by one
        if char in v_list:            
            v_dict[char] += 1
            
    #For loop that goes through the list of characters in the string 
    for char in char_list:
        
        if char in c_dict:
            c_dict[char] += 1
    
    #Creating empty dictionary to return later
    letter_totals = dict()
    
    #sum all the values in the vowels dictionary and make that the value of 
    #total vowels key
    letter_totals['total_v_sum'] = sum(v_dict.values())
    
    #sum all the values in the cons dictionary and make that the value of 
    #total cons key
    letter_totals['total_c_sum'] = sum(c_dict.values())

    #Return the dictionary key/values as a list to print later 
    return [letter_totals['total_v_sum'],letter_totals['total_c_sum']]

#If the name of the terminal that the program is run in is 'main'
if __name__ == '__main__':
    #Run vc_counter program with the user_input as an argument
    vc_counter(user_input)
    #Print the 0th element in the list for vowel, print the 1st element for 
    #consonants
    print('Total # of vowels in sentence:',vc_counter(user_input)[0])
    print('Total # of consonants in sentence:',vc_counter(user_input)[1])
    