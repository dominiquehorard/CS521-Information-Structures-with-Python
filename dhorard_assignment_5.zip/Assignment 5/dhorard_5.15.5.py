# -*- coding: utf-8 -*-
"""
Created on Fri Apr 16 13:49:56 2021

@author: Dom Horard
CS521 O2
04/16/2021
Write a python program that does the following:
    
• Prompt the user on three lines for principal, 
percent interest rate and number of years to invest (using descriptive prompts)

    o Use a while loop to keep prompting until entries are valid
    
• Call your function calc_compound_interest() that:
    o takes the arguments principle, int_rate, years
    o uses the above formula to calculate the ending value of the account
    o returns the value
    
• Call a second function calc_compound_interest_recursive() that:
    o takes the arguments principle, int_rate, years
    o calculates the value recursively – calling a base calculation over and  
        over instead of using the number of year as an exponent.
    o return that value
    
• Print both values with clear descriptions and formatted with thousand commas 
and 2 decimal places. 
Then print whether the two values are equal when rounded to 4 decimal places.
"""
#Import module to check for punctuation later
import string

#While loop to reprompt the user for input if it's invalid
while True:
    
    p_val = input('Please enter an initial principal value: ')
    i_val = input('Please enter in the intrest rate as a whole number' + \
                        ' (Hint: multiply rate by 100): ')
    n_val = input('Please enter in the number of years: ')
    
    #Check if the value is a number 
    if p_val.isalpha() or p_val in string.punctuation or p_val.isdigit() == \
        False:
        print('***Please only enter numbers for the initial principal value.' \
              + ' No Positive or Negative signs.***')
    
    #Check if the value is a number
    if i_val.isalpha() or i_val in string.punctuation:
        print('***Please only enter numbers for the interest rate.' + \
              + ' No Positive or Negative signs.***')
    
    #Check if the value is a number
    if n_val.isalpha() or n_val in string.punctuation or n_val.isdigit() == \
        False:
        print('***Please only enter numbers for the number of years.' + \
              + ' No Positive or Negative signs.***')
    
    #Check if the number is greater than 0
    elif float(i_val) / 100 <= 0:
        print('***Please enter a number that is greater than 0 for your' + \
              ' interest rate***')
            
    #Break if all inputs are valid
    else:
        break

#Convert the inputs into floats for calculations later
#Divide value for interest by 100 to ensure that it's a decimal
p = float(p_val)
i = float(i_val) / 100
n = float(n_val)

#Function that takes the user input for 
def calc_compound_interest(principal, int_rate, years):
    """
    Parameters
    ----------
    p : float of the user entered principal value.
    i : flaot of the user entered interest rate.
    n : float of the user entered number of years.

    Returns
    -------
    Value of the account after calculating for compound interest

    """
    #Calculate the final account value and format for commas and round up to 2
    #decomal places
    result = p * (1 + i)**n
    
    #return value of result
    return result

#Function for recursive compound calculation
def calc_compound_interest_recursive(principal, int_rate, years):
    '''
    Parameters
    ----------
    p : float of the user entered principal value.
    i : flaot of the user entered interest rate.
    n : float of the user entered number of years.

    Returns
    -------
    Value of the account after calculating for compound interest recursivly
    '''
    #If the year is 0, then the end of the timefram for the account has
    #been reached
    if years == 0:
        return principal
    
    #Iterate through years - 1 until the end, 0, has been reached
    else:
        recursive_result = calc_compound_interest(principal * int_rate, \
                                                  int_rate, years - 1)
            
    #Return that recursive value
    return recursive_result
        
        
#If the name of the terminal that the program is run in is 'main'
if __name__ == '__main__':
    #Variable equal to the value of the function ran with the arguments
    reg_result = calc_compound_interest(p, i, n)
    #Variable storing the value returned by the recursive function
    recursive_result = calc_compound_interest_recursive(p, i, n)
    
    #Print that the values are equal if they are equal
    #format with the  dollar sign and 4 decimal places
    if reg_result == recursive_result:
        print('Recursive interest value' + \
              ' ${:,.4f}'.format(recursive_result) + ', and regular interest'\
                  + ' value ${:,.4f}'.format(reg_result) + ' are equal.')
            
    #Print values format with the dollar sign and 2 decimal places        
    elif reg_result != recursive_result:
        print()
        print('Here is the final value from the normal function:' + \
              ' ${:,.2f}'.format(reg_result))

        print('Here is the final value from the recursive function:' + \
              ' ${:,.2f}'.format(recursive_result))