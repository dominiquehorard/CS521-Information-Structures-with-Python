# -*- coding: utf-8 -*-
"""
Created on Fri Apr 16 08:19:41 2021

@author: Dom Horard
CS521 O2
04/16/2021
Write a python program that does the following: 

Prompts the user for three numbers in one request. 
Be sure to specify the “delimiter” by which a user enters those three numbers.

Divides first number by second number and add that result to the third number. 
Prints output that shows in one line the formula applied 
and the result of the calculation. Validate input by:
    
• Checking the user entered 3 values
• Appropriately checking for the following errors: ValueError and 
ZeroDivisionError.
• Printing descriptive error messages to the console if validation fails.
• Remembering to have very granular testing blocks
"""
import sys

#Putting input in a try statement so the program can try assigning values to 
#variables
try:
    #Three variables for 3 numbers, split by space
    num_1, num_2, num_3 = input('Please enter 3 numbers seperated by' + \
                                ' a space: ').split()
#Try returns a value error, print message and exit
except ValueError:
            print('Please enter 3 numbers')
            sys.exit()
#If the correct amount of values were input move to dividing first and second
#numbers            
else:
    
    #Try dividing the int conversion of num 1 by int conversion of num 2 
    try:
        num_divided = float(num_1) / float(num_2)
        
    #If try returns a Zero division error, print error and exit
    except ZeroDivisionError:
        print('Your second number cannot be a 0')
        sys.exit()
    
    #Catch value error if letter was entered
    except ValueError:
        print('Please only enter numbers')
        sys.exit()
        
    #Otherwise, take the result of the division and add that to num 3
    else:
        
        #Final try to ensure num 3 is a number
        try:
            num_added = float(num_divided) + float(num_3)
            
        #Catch value error if letter was entered
        except ValueError:
            print('Please only enter numbers')
            sys.exit()
        
        #Store value of the result in a variable and add formatting for 
        #thousands and rounding
        else:
            result = '{:,.2f}'.format(num_added)

#Print the calculations as a string concatenated
print('(' + str(num_1) + ' / ' + str(num_2) + ') ' + '+ ' + str(num_3) + ' = '\
              + str(result))
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    