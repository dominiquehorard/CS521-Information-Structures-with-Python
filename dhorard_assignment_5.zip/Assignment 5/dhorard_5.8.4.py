# -*- coding: utf-8 -*-
"""
Created on Fri Apr 16 09:33:49 2021

@author: Dom Horard
CS521 O2
04/16/2021

Write a python program that does the following: 
    Prompt for a file name of text words. 
    
    Words can be on many lines with multiple words per line. 
    
    Read the file and convert the words to a list. 
    
    Call a function you created called list_to_words(), 
    that takes a list as an argument and returns a list that contains 
    only words that occurred once in the file. 
    
    Print the results of the function with an appropriate description.
"""
#Import sys module to exit if there is an error with opening the file
import sys

#Import string module to exclude characters from the word list
import string

#Prompt user for a file name
user_file = input('Please enter a file name: ')

#Try block to open and read the file
try:
    i_file = open((user_file), 'r')

#Returns meesage for a file not found error
except FileNotFoundError:
    print('This file does not exist')
    sys.exit()
    
#Else statement to create the word list that will be the argument for the 
#function
else:
    #List comprehension to make a list of lists for lines as they are seperated 
    #by new line character
    line_list = [line.split() for line in i_file.readlines()]

    #list comprehension to turn the lines list into a flat list of the words 
    #with punctuation included
    flat_list = [item for sublist in line_list for item in sublist]

    #Empty list to append words without punctuation into
    pure_list = []
    
    #Empty list to append just the words into
    word_list = []
    
    #For loop that appends words to the word list, but strips all punctuation 
    #first
    for item in flat_list:
        pure_list.append(item.strip(string.punctuation))
    
    #Lowercase each word in the pure list    
    for words in pure_list:
        word_list.append(words.lower())
    

def list_to_words(list):
    '''
    Parameters
    ----------
    list : list of words

    Returns
    -------
    the list of unique words

    '''
    #Empty list to append unique words to
    unique_words = []
    
    #Creating a word dictionary with all the words from the file, default value
    #is 0
    word_dict = {word:0 for word in list}

    #For loop that checks if the word from the word list is in wird_dict
    for word in list:
        
        #If it is, increment the value by 1
        if word in word_dict:
            word_dict[word] += 1
            
    
    
    #For the words and values in the dictionary
    for word,value in word_dict.items():
        
        #Append the word to the unique words dictionary if the value is 1
        if value == 1:
           unique_words.append(word)
    
    return unique_words

i_file.close()

#If the name of the terminal that the program is run in is 'main'
if __name__ == '__main__':
    #Variable equal to the value of the function ran with the word_list arg
    unique_words = list_to_words(word_list)
    print('Here is the list of unique words:', unique_words)

