# -*- coding: utf-8 -*-
"""
Created on Sun Apr  4 11:57:16 2021

@author: Dom Horard
CS 521 O2
4/4/21
Create a text file containing student records
Write a program to read the file line by line 
and store all the records in lists or tuples.
"""
#Question 3.14.6
#Import sys module to exit the application
import sys

#Check if the file specified exists
try:
    i_file = open('\\Users\Dom Horard\Desktop\CS521\\'+
                  '\Assignments\Assignment 3\Q6.txt','r')
#Print an error and exit if file does not exist using .exit function
except:
    print('File does not exist')
    sys.exit()
#Else statement to continue on with the rest of the program if the file exists
else:
    #Open output file to write to
    o_file = open('Q6_output.txt','w')
    
    #Extract the record data from the file as a string
    records_data = i_file.readlines()
    
    #For each record in the list, saved as a string, separate the elements in 
    #the list by the commas that separate each element
    for record in records_data:
        records_list = [records.split(',') for records in records_data]
        
#Print the new list
print(records_list)
#Close the connection to the files
i_file.close()
o_file.close() 