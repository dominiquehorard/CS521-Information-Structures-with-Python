# -*- coding: utf-8 -*-
"""
Created on Sat Apr  3 15:31:54 2021

@author: Dom Horard
CS 521 O2
4/3/21
Write a program that reads the file and writes the words to a new text file so
that there are four lines of five single spaced words.
"""
#Question 3_6_5
#Import sys module to exit the application
import sys

#Check if the file specified exists
try:
    i_file = open('PUT YOUR INPUT FILE DESTINATION HERE','r')
#Print an error and exit if file does not exist using .exit function
except:
    print('File does not exist')
    sys.exit()
#Else statment to continue on with the rest of the program if the file exists
else:
    #Open output file to write to
    o_file = open('PUT YOUR OUTPUT FILE DESTINATION HERE','w')
    
    #Extract the sentence from the file as a string
    sentence = i_file.readline()
    #Make a list of the words in the sentence
    word_list = sentence.split()
    
    #Variables to check the sentence word limit,and seperate words
    sent_word_lim = 20
    word_lim = 5
    word_count = 0
    
    #Increment word_count variable for each element in the word_list list
    for words in word_list:
        word_count += 1
    #First check if the value of word_count variable is equal to 20
    if word_count != sent_word_lim:
        print('The input file needs to have a 20 word sentence')
    else:
        #create a new list that is a list of the lists
        #the list is elements from word_list from i, equaling 0 to i + value  
        #stored in word_lim. 
        #Seperating the amount of words in this list by value of word_lim
        split_word_list = [word_list[i:i + word_lim] for i in range(0,len\
                                                                (word_list),\
                                                                word_lim)]
        #Join the words in each list in the lists to make a string of the words
        split_strings = [' '.join(ele) for ele in split_word_list]
        #Print each list in the lists to the output file on seperate lines
        print(*split_strings, sep='\n', file=(o_file))
        
#Close the connection to the files
i_file.close()
o_file.close()    
    