# -*- coding: utf-8 -*-
"""
Created on Tue Mar 30 20:14:38 2021

@author: Dom Horard
CS 521 O2
3/30/21
Write a Python program that counts the number of odd numbers, even numbers, 
squares of an integer and cubes of an integer from 2 to 130 (inclusive).
"""
#Question 3_2_1
#Constants to store start and end values
S = 2
E = 130

#Defining the variables for use later when displaying the totals
even_nums, odd_nums, sqr_nums, cube_nums = 0, 0, 0, 0

#Defining the range E + 1 to include 130
numbers = list(range(S,E + 1))

#Empty lists to store the numbers for use later
odd_num_list = []
even_num_list = []
sqr_num_list = []
cube_num_list = []

print('Checking numbers from {}'.format(S), 'to {}'.format(E))

#Check if the value in the range is an odd number
#For each number in the list
for i in numbers:
    
    #If the number leaves a remainder when devided by 2
    if i % 2 != 0:
        #Append that number to the odd_num_list
        odd_num_list.append(i)
        #Increment odd_nums by 1
        odd_nums += 1
#Print the total odd numbers in that string using the format function. Also
#print the start and the end of the odd_num_list
print('Odd ({}): {}...{}'.format(odd_nums, odd_num_list[0],odd_num_list[-1]))

#Check if the value in the range is an even number
#For each number in the list 
for i in numbers:
    if i % 2 == 0: 
        #If the number leaves no remainder when devided by 2
        even_num_list.append(i)
        #Increment even_nums by 1
        even_nums += 1
#Print the total even numbers in that string using the format function. Also
#print the start and the end of the even_num_list
print('Even ({}): {}...{}'.format(even_nums,even_num_list[0],even_num_list[-1]\
                                  ))

#Check if the number is a square
#For each number in the list 
for i in numbers:
    #Squaring each number in the list and storing that value in a variable
    sqred_num = i ** 2
    #If that number is in the list of numbers
    if sqred_num in numbers:
        #Append to the sqred_num list
        sqr_num_list.append(sqred_num)
        #sqr_nums variable gets incremented by 1
        sqr_nums += 1
#Print the total square numbers in that string using the format function. Also
#print the start and the end of the sqr_num_list
print('Square ({}):'.format(sqr_nums),sqr_num_list)

#Check if the value in the range is a cube
#For each number in the list
for i in numbers:
    #Cubing each number in the list and storing that value in a variable
    cubed_num = i ** 3
    #If that number is in the list of numbers
    if cubed_num in numbers:
        #Append to the cube_num list
        cube_num_list.append(cubed_num)
        #cube_nums variable gets incremented by 1
        cube_nums += 1
#Print the total cubed numbers in that string using the format function. Also
#print the start and the end of the cube_num_list
print('Cube ({}): '.format(cube_nums),cube_num_list)

#Made seperate for loops because the loop would not count the squared 
#values that it passed through in the previous iteration
#It was omitting 4, 9, 16, 25
