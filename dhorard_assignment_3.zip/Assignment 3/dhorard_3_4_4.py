# -*- coding: utf-8 -*-
"""
Created on Fri Apr  2 15:29:15 2021

@author: Dom Horard
@author: Dom Horard
CS 521 O2
4/2/21

Write a program that prompts the user to enter a three‐digit whole number such
that the digits are in ascending order and without duplicates.
Valid examples: 123 and 489
Invalid examples: 133 and 174
The program loops and re‐prompts the user until a correct value is entered. 
Make sure to check whether the user entered the correct data type.
"""
#Question 3_4_4
#Variables that will be used to compare the values of the digits in the number 
#entered by the user
h,i,j = 0,1,2

#While true is used to re-prompt the user for a number until a false is 
#returned from the if/elif statments
while True:
    
    #Prompt the user to input a number, specifying it needs to be 3 digits
    user_num = input('Please enter a 3-digit number: ')
    #Store the length of that string to compare later
    num_len = len(user_num)
    #Storing the individual digits in the number to compare for ascending order
    #and to ensure there are no duplicates
    num_list = list(user_num)
    
    #If length of user input is not equal to 3, print error and re-prompt
    if num_len != 3:
        print('Error: You did not enter a 3-digit number, please re-enter.')
    #If user's input contains a character that isn't a number, and is a letter,
    #print error and re-prompt
    elif user_num.isdigit() == False and (user_num.isupper() or \
                                          user_num.islower()):
        print('Error: You entered 1 or more letters. Please re-enter with numb'
              + 'ers only.')
    #If the user's entry contians a decimal, print error and re-prompt
    elif '.' in user_num:
        print("Error: The number you entered has a decimal or special character"
              + ". Please only enter whole numbers.")
    #Using the variables defined, check if any of the digits in the list is 
    #equal to another. If so, print an error and re-prompt
    elif num_list[h] == num_list[i] or (num_list[j] == num_list[i]) \
        or (num_list[h] == num_list[j]):
        print('Error: Your number contains duplicate digits. Please re-enter.')
    #Using variables, check if all the values ascend in the list. If they don't
    #Print error and re-prompt
    elif (num_list[h] > num_list[i]) or (num_list[i] > num_list[j]) \
        or (num_list[h] > num_list[j]):
        print('Error: Your number contains digits that are not in' +
              ' ascending order. Please re-enter.')
    #If all of those return False, then the number meets the criteria. 
    #End program
    else:
        print('Number Accepted!')
        break
