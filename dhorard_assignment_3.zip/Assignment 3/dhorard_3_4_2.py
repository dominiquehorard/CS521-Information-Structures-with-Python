# -*- coding: utf-8 -*-
"""
Created on Thu Apr  1 15:24:41 2021

@author: Dom Horard
CS 521 O2
4/1/21
Set a constant with an odd length string.
Confirm in code that the string is of an odd length. Otherwise, print message 
for the user and end the program.
For a string of odd length, print each of the following in double quotes:
 Print the entire string and its length.
 Print the middle character.
 Print the string up to but not including the middle character.
 Print the string from immediately following the middle character to the end.
"""
#Question 3_4_1
#Defined a constant with an odd lengthed string
X = 'This is an odd lengthed string!'

#If statement to take the length of the string stored in X, and see if the
#length when divided by 2 does not have a remainder that equals 0
if len(X) % 2 != 0:
    
    #Store the length of the constant in a variable for easier use
    length = len(X)
    
    #Floor division the length by 2 and store that as the middle character
    mid_char = length // 2
    
    #Using .format function print the length value of the string and then
    #the string itself
    print('My {}-character string is:'.format(len(X)),'\"{}\"'.format(X))
    
    #Using the mid_char variable, this prints the middle charcter in the string
    print('The middle character is: ','\"{}\"'.format(X[mid_char]))
    
    #Using string sequences print the string from default [0] to the [mid_char]
    print('The 1st half of the string is:', '\"{}\"'.format(X[:mid_char]))
    
    #Using string sequences print the string from [mid_char + 1] to the default 
    #end of the string
    print('The 2nd half of the string is:', '\"{}\"'.format(X[mid_char + 1:]))
else:
    
    #Print message that the string is not odd
    print('The string entered is not odd in legnth. Goodbye!')
       



