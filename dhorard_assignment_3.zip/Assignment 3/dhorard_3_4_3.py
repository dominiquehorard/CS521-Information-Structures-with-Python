# -*- coding: utf-8 -*-
"""
Created on Fri Apr  2 08:52:03 2021

@author: Dom Horard
CS 521 O2
4/2/21
Write a program that prompts the user for a sentence and calculates the number 
of uppercase letters, lowercase letters, digits, and punctuation. 
Output the results neatly formatted, centered and labeled in columns. 
Use Python 3's f‐Strings or format() to solve.
Check out the library attribute string.punctuation for help in solving this
problem. Spaces are NOT considered punctuation.
"""
#Question 3_4_3
#Import string module to use later when counting the punctuation marks
import string

#Prompt the user for a sentence
user_input = input('Type a sentence: ')

#Define variables that will be displayed later for the totals
upper_count,lower_count,num_count,punc_count = 0,0,0,0

#Define the names for the headers
U = "Upper"
L = "Lower"
D = "Digits"
P = "Punct."

#Define variable that stores the underline for the header
T = "-" * 9

#Define variable that stores the separator between the column headers
H = '#'

#For loop that goes through each charcter in the user input
for char in user_input:
    #If the character is uppercase increment upper_count up 1
    if char.isupper():
        upper_count += 1
    #If the character is lowercase increment lower_count up 1
    elif char.islower():
        lower_count += 1
    #If the character is a digit increment num_count up 1
    elif char.isdigit():
        num_count += 1
    #If the character is found in .punctuation() for string,
    #increment punc_count up 1
    elif char in string.punctuation:
        punc_count += 1

#Formatting the '#' 2 spaces from the right, and the headers 10 spaces from the 
#right
print("{:<2s}{:<10s}{:<2s}{:<10s}{:<2s}{:<10s}{:<2s}{:<10s}".format(H,U,H,L,\
                                                                    H,D,H,P))
#Print the dashes 12 from the right
print("{:<12s}{:<12s}{:<12s}{:<12s}".format(T,T,T,T))

#Print the totals, centered, between 9 or 15 spaces
print("{:^9}{:^15}{:^9}{:^15}"\
      .format(upper_count,lower_count,num_count,punc_count))
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    